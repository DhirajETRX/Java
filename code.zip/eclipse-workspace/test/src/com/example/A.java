package com.example;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

//WAJP to count strings whose length is greater than 4 in the given list
public class A {
	public static void main(String[] args) {
//		String s="Welcome to Java world Mr. Dhiraj Kumar";
//		String s1[]=s.split(" ");
//		int count=0;
//		for(String str:s1) {
//			if(str.length()>4) {
//				count=count+1;
//				System.out.println(str);
//			}
//		}System.out.println(count);
		
		String s="Welcome to Java world Mr. Dhiraj Kumar";
		String s1[]=s.split(" ");
		List<String> list=Arrays.asList(s1);
		Long count = list.stream().filter(e->e.length()>4).count();
		System.out.println(count);
		list.stream().filter(p->p.length()>4).collect(Collectors.toList()).forEach(System.out::println);
	}
}
