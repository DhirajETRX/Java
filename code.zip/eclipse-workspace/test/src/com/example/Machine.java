package com.example;

import java.util.Scanner;

public class Machine {

	public static void main(String[] args){
		
		Scanner sc=new Scanner(System.in);
		int coke_price=35;
		int pepsi_price=45;
		int soda_price=55;

		System.out.println("Welcome to machine");
		System.out.println("1. coke- rs "+coke_price);
		System.out.println("2. pespsi- rs "+pepsi_price);
		System.out.println("3. soda-rs "+soda_price);
		
		System.out.println("Enter choice(1-3)");
		int choice=sc.nextInt();
		
		System.out.println("insert coins(1,5,10,25");
		int coins=sc.nextInt();
		
		int price=0;
		String product="";
		
		switch(choice) {
		case 1:
			price = coke_price;
			product="coke";
			break;
			
		case 2:
			price = pepsi_price;
			product="pepsi";
			break;
			
		case 3:
			price = soda_price;
			product="soda";
			break;
			
		default:
			System.out.println("Invalid input");
			return;
		}
		
		if(coins<price) {
			System.out.println("Less amount please enter more amount");
		}else {
			int change=coins-price;
			System.out.println("Dispensing "+product);
			System.out.println("Change rs "+change);
		}
		
		System.out.println("Do you want to refund(Yes/no)");
		String refundChoice=sc.next();
		
		if(refundChoice.equalsIgnoreCase("yes")) {
			System.out.println("Refund money "+coins);
		}
		
		
		}
}
	
