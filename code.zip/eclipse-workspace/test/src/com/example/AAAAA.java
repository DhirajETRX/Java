package com.example;

import java.util.HashMap;
import java.util.Map;

public class AAAAA {
	
	public static void main(String[] args) {
		String s="Dhirajjjjjjjj";
		Map<Character, Integer> map=new HashMap<>();
		char[] c=s.toCharArray();
		for(char ch:c) {
			if(map.containsKey(ch)) {
				map.put(ch, map.get(ch)+1);
			}else {
				map.put(ch, 1);
			}
		}
		int maxCount=0;
		char maxChar=' ';
		for(Map.Entry<Character, Integer> me: map.entrySet()) {
			if(maxCount < me.getValue()) {
				maxCount=me.getValue();
				maxChar=me.getKey();
			}
		}System.out.println("max char : "+maxChar);
	}
}
