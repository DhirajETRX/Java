package com.example;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class AAAAAA {
	public static void repeatChar(String s) {
		Map<Character, Integer> hm=new HashMap<>();
		s=s.replaceAll("\\s", "");
		char[] c=s.toCharArray();
		for(char ch:c) {
			if(hm.containsKey(ch)) {
				hm.put(ch, hm.get(ch)+1);
			}else {
				hm.put(ch, 1);
			}
		}
		int maxCount=0;
		char maxChar=' ';
		for(Map.Entry<Character, Integer> me:hm.entrySet()) {
			if(maxCount<me.getValue()) {
				maxCount=me.getValue();
				maxChar=me.getKey();
			}
		}System.out.println(maxChar+" : "+maxCount);
		System.out.println(s +":"+ hm);
		
		for(char ch:hm.keySet()) {
			if(hm.get(ch)>1) {
				System.out.println(ch+" : "+hm.get(ch));
			}
		}
	}
	public static void main(String[] args) {
		String s="hello I am Dhiraj Kumaaaaar";
		repeatChar(s);
	}
}
