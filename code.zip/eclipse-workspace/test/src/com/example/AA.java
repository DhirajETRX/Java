package com.example;

import java.util.Scanner;

public class AA {
	
	public int fibo(int n,int a,int b,int c) {
		
		
		for(int i=0;i<=n;i++) {
			c=a+b;
			System.out.println(c);
			a=b;
			b=c;
		}
		return c;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter value of n : ");
		int n=sc.nextInt();
		System.out.println("Enter value of a : ");
		int a=sc.nextInt();
		System.out.println("Enter value of b : ");
		int b=sc.nextInt();
		AA a1=new AA();
		int res = a1.fibo(n, a, b, b);
		System.out.println(res);
		
	}
}
