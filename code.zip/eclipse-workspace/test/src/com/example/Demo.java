package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class Demo {
	
	public static void main(String[] args) {
		int arr1[]= {2,4,6,5};
		int arr2[]= {4,2,5,6};
		
		Arrays.sort(arr1);
		Arrays.sort(arr2);
		if(arr1.length==arr2.length) {
			for(int i=0;i<arr1.length;i++) {
				if(arr1[i]==arr2[i]) {
					System.out.println("Arrays are same");
				}else {
					System.out.println("Arrays not are same");
				}
			}
		}
	}
}
