package com.example;

import java.util.Scanner;

public class Calci {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Choose your brand : ");
		System.out.println("1. Panasonic \n"+"2. Casio \n"+"3. Sony");
		System.out.println("Enter your brand choice 1 to 3 : ");
		int brand = sc.nextInt();
		switch (brand) {
		case 1:
			if(brand==1) {
				System.out.println("Hey You have choosed Panasonic");
			}
			break;
			
		case 2:
			if(brand==2) {
				System.out.println("Great You have choosed Casio");
			}
			break;
			
		case 3:
			if(brand==3) {
				System.out.println("Hey dude You have choosed Sony");
			}
			break;

		default:
			System.out.println("Enter valid option");
			break;
		}
		
		System.out.println("Enter value of A : ");
		int a=sc.nextInt();
		System.out.println("Enter value of B : ");
		int b=sc.nextInt();
		System.out.println("Choose your operation :");
		System.out.println("Press 1 for addtion");
		System.out.println("Press 2 for substraction");
		System.out.println("Press 3 for multiplication");
		System.out.println("Press 4 for division");
		System.out.println("Press 5 for modulus");
		int cal=sc.nextInt();
		switch (cal) {
		case 1:
			if(cal==1)
				System.out.println("Addition of these number is : "+a+b);
			break;
			
		case 2:
			if(cal==2)
				System.out.println("Substraction of these number is : "+(a-b));
			break;
			
		case 3:
			if(cal==3)
				System.out.println("Multiplication of these number is : "+a*b);
			break;
			
		case 4:
			if(cal==4)
				System.out.println("Division of these number is : "+(a/b));
			break;
			
		case 5:
			if(cal==5)
				System.out.println("Addition of these number is : "+(a%b));
			break;

		default:
			System.out.println("Sorry operation can not perform!! please enter valid option");
			break;
		}
	}
}
