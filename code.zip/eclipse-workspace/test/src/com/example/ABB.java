package com.example;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ABB {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter input : ");
		String s=sc.nextLine();
//		String s="Hi I am dhiraj Kumar from jharkhand!!";
		s=s.replaceAll("\\s", "");
		Map<Character, Integer> map=new HashMap<>();
		char[] c=s.toCharArray();
		for(char ch:c) {
			if(map.containsKey(ch)) {
				map.put(ch, map.get(ch)+1);
			}else {
				map.put(ch, 1);
			}
		}System.out.println(map);
		for(char ch:map.keySet()) {
			if(map.get(ch)==1) {
				System.out.println(ch+" : "+map.get(ch));
			}
		}
		for(char ch:c) {
			if(map.get(ch)>1) {
				System.out.println("First repeated charecter is : "+ch);break;
			}
		}
		for(char ch:c) {
			if(map.get(ch)==1) {
				System.out.println("First non-repeted charecter is : "+ch);break;
			}
		}
		int maxCount=0;
		char maxChar=' ';
		for(Map.Entry<Character, Integer> me:map.entrySet()) {
			if(maxCount<me.getValue()) {
				maxCount=me.getValue();
				maxChar=me.getKey();
			}
		}System.out.println(maxChar+" : "+maxCount);
	}
}
