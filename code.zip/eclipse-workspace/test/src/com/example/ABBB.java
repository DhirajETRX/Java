package com.example;

import java.util.ArrayList;
import java.util.List;

//WAJP to separate positive and negative numbers from an array and print the count of 
//total positive and negative number
//input
//arr[]=2,5,4,-6,-3,-8,9,7,-9,3
//output
//total positive number are =7
//{2,5,4,9,7,3}
//total negative number are =4
//{-6,-3,-8,-9}

public class ABBB {
	public static void main(String[] args) {
		int arr[]= {2,5,4,-6,-3,-8,9,7,-9,3};
		int parr[]=new int[arr.length];
		int narr[]=new int[arr.length];
		int pcount=0,ncount=0;
		int psum=0,nsum=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>0) {
				parr[pcount]=arr[i];
				pcount++;
				psum=psum+arr[i];
			}else {
				narr[ncount]=arr[i];
				ncount++;
				nsum=nsum+narr[i];
			}
		}System.out.println("Total +ve elements are : "+pcount);
		System.out.println("Total -ve elements are : "+ncount);
		System.out.println("Total -ve arrays are : "+narr);
		for(int i=0;i<parr.length;i++) {
			System.out.println("Total +ve arrays are : "+parr[i]);
		}
	}
}
