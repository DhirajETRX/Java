package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AAA {
	

	public static void main(String[] args) {
		String s = "hello geeks for geeks is computer science portal";
		int k=4;
		String ch[]=s.split(" ");
		System.out.println(ch);
		List<String> list = new ArrayList<>();
		for(String str:ch) {
			if(str.length()>k) {
				list.add(str);
			}
		}System.out.println(list);
	}
}
