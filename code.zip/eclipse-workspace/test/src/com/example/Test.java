package com.example;
//Remove Duplicate Element in Array using Temporary Array
public class Test {
	
	
	public static void main(String[] args) {
		int arr[] = {10,20,20,30,30,40,50,50};
		int temp[]=new int[arr.length];
		int k=0;
		for(int i=0;i<arr.length-1;i++) {
			if(arr[i]!=arr[i+1]) {
				temp[k]=arr[i];
				k++;
			}
		}
		temp[k]=arr[arr.length-1];
		for(int i=0;i<temp.length;i++) {
			System.out.println(temp[i]);
		}
		
		int l=3;
		for(int i=0;i<temp.length-1;i++) {
			for(int j=i+1;j<temp.length;j++) {
				if(temp[i]<temp[j]) {
					int help=temp[i];
					temp[i]=temp[j];
					temp[j]=help;
				}
			}
			if(i==l-1) {
				System.out.println("3rd largest element is --> "+temp[i]);
			}
		}
		for(int c:temp) {
			System.out.println("Sorted element "+c);
		}
	}

}
