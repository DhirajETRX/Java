package com.example.set;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetDemo {
	public static void main(String[] args) {
		TreeSet ts=new TreeSet<>();
		ts.add(100);
		ts.add(50);
		ts.add(150);
		ts.add(25);
		ts.add(75);
		ts.add(125);
		ts.add(175);
		System.out.println(ts);
		Iterator itr=ts.iterator();
		while(itr.hasNext()) {
			System.out.print(itr.next()+", ");
		}
		
	}
}
