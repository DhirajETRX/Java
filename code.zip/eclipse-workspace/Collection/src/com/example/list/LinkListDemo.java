package com.example.list;

import java.util.Collections;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkListDemo {
	public static void main(String[] args) {
		LinkedList<String> list = new LinkedList<>();
		list.add("Dhiraj");
		list.add("Advait");
		list.add("Arush");
		list.add("Anvika");
		list.add(1, "Prithvi");
		list.addFirst("Anju");
		list.addLast("Mehta");
		System.out.println(list);
		Collections.sort(list);
		System.out.println(list);
		String a= list.peek();
		System.out.println(a);
		String b=list.peekFirst();
		System.out.println(b);
		String c=list.peekLast();
		System.out.println(c);
		list.pollLast();
		System.out.println(list);
		list.pop();
		System.out.println(list);
 		System.out.println(list);  
		
	}
}
