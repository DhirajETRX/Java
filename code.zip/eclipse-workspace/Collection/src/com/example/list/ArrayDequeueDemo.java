package com.example.list;

import java.util.ArrayDeque;

public class ArrayDequeueDemo {
	public static void main(String[] args) {
		ArrayDeque ad=new ArrayDeque<>();
		ad.add(62);
		ad.add(23);
		ad.add(88);
		ad.add(65);
		ad.add(12);
		ad.addFirst(55);
		ad.addLast(51);
		System.out.println(ad);
		System.out.println(ad.contains(65));
	}
}
