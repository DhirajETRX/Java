package com.example.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		al.add(87);
		al.add(776);
		al.add(21);
		al.add(34);
		al.add(34);
		al.add(564);
		System.out.println(al);
		al.add("RAM");
		al.add("SITA");
		al.add(null);
		al.add(true);
		System.out.println(al);
		al.add(3, 435);
		System.out.println(al);
		
		ArrayList al1=new ArrayList();
		al1.add("SITARAM");
		al1.add(56);
		al1.add(1, "LAKHAN");
		System.out.println(al1);
		al.addAll(al1);
		System.out.println(al);
		al.addAll(6, al1);
		System.out.println(al);
		System.out.println(al.get(1));
		System.out.println(al.contains(34));
		int a=al.lastIndexOf(56);
		System.out.println(a);
		System.out.println(al.indexOf(435));
		al.remove(3);
		System.out.println(al);
//		al.retainAll(al1);
//		System.out.println(al);
		
//		Iterator itr=al.iterator();
//		while(itr.hasNext()) {
//			System.out.print(itr.next()+", ");
//		}
		
//		ListIterator litr=al.listIterator();
//		while (litr.hasNext()) {
//			System.out.print(litr.next()+", ");
//		}
		
		
		
		
		ListIterator litr=al.listIterator();
		while (litr.hasPrevious()) {
			System.out.print(litr.previous()+", ");
		}
	}
}
