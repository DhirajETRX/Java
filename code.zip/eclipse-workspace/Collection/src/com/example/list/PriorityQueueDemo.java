package com.example.list;

import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQueueDemo {
	public static void main(String[] args) {
		PriorityQueue pq=new PriorityQueue();
		pq.add(100);
		pq.add(50);
		pq.add(150);
		pq.add(25);
		pq.add(70);
		pq.add(125);
		pq.add(175);
		System.out.println(pq);
		Iterator itr=pq.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
