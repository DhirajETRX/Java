package com.example;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

//WAJP to swap two number without using third variable
//Input 
//num1=10
//num2=20
//Output
//num1=20
//num2=10
public class Demo8 {
	public static void main(String[] args) {
//		int x=10;
//		int y=20;
//		x=y+x;
//		y=x-y;
//		x=x-y;
//		System.out.println("value of x "+x+" value of y "+y);
		
		
		String s1="cloud";
		String s2="tech";
		System.out.println("S1 value befor swap "+s1);
		System.out.println("S2 value befor swap "+s2);
		
		s1=s1+s2;
		s2=s1.substring(0, s1.length()-s2.length());
		s1=s1.substring(s2.length());
		System.out.println("S1 value after swap "+s1);
		System.out.println("S2 value after swap "+s2);
	}
}


//Scanner sc=new Scanner(System.in);
//System.out.println("Enter your string");
//String s=sc.nextLine();
//Set<Character> cs=new HashSet<>();
//for(char c:s.toCharArray()) {
//	if(cs.contains(c)) {
//		System.out.print(c+" ");
//	}else {
//		cs.add(c);
//	}
//}
//}
//	}
