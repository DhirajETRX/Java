package com.example;
//WAJP to determine whether one string is rotation of another
//Input
//String 1=cloudtech
//String 2=techcloud
//Output - String 2 is rotation of String 1
//Input
//String 1=cloudtech
//String 2=cloudcloud
//Output - String 2 is not rotation of String 1


public class Demo7 {
	public static void main(String[] args) {
		
		
//		String str1="cloudtech";
//		String str2="techcloud";
//		if(rotation(str1, str2)) {
//			System.out.println("String 2 is rotation of string 1");
//		}else {
//			System.out.println("String 2 is not rotation of string 1");
//		}
//	}
//	public static boolean rotation(String str1,String str2) {
//		if(str1.length()!=str2.length()) {
//			return false;
//		}
//		for(int i=0;i<str1.length();i++) {
//			str1=str1+str1;
//			if(str1.indexOf(str2)!=-1) {
//				return true;
//			}else {
//				return false;
//			}
//		}
//		return false;
		
		
		//Another way without method
//		String str1="cloudtech";
//		String str2="techcloud";
//		if(str1.length()!=str2.length()) {
//			System.out.println("String 2 is not rotation of string 1");
//		}
//		str1=str1+str1;
//		if(str1.indexOf(str2)!=-1) {
//			System.out.println("String 2 is rotation of String 1");
//		}else {
//			System.out.println("String 2 is not rotation of string 1");
//		}
		
		
		
		String str1="cloudtech";
		String str2="techcloud";
		String str3=str1+str1;
		if(str3.contains(str2)) {
			System.out.println("String 2 is rotation of String 1");
		}else {
			System.out.println("String 2 is not rotation of String 1");
		}
	}
}
