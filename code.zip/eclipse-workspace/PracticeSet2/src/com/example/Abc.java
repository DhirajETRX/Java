package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;

public class Abc {
	public static void main(String[] args) {
		
		int arr[]= {1,2,3,1,4,2,5,6,2,3,6,4,8};
		Map<Integer, Integer> map=new HashMap();
		for(int i:arr) {
			if(map.containsKey(i)) {
				map.put(i, map.get(i)+1);
			}else {
				map.put(i, 1);
			}
		}System.out.println(Arrays.toString(arr));
		System.out.println(map);
		for(int i:map.keySet()) {
			if(map.get(i)>1) {
				System.out.println(i+" "+map.get(i));
			}
		}
		for(int i:arr) {
			if(map.get(i)==1) {
				System.out.println("First non repeated integer "+i);
				break;
			}
		}
		for(int i:arr) {
			if(map.get(i)>1) {
				System.out.println("First repeated integer "+i+" "+map.get(i));
				break;
			}
		}
	}
}
