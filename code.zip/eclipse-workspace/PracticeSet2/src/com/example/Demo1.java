package com.example;

public class Demo1 {
	public static void main(String[] args) {
//		int arr[]= {1,2,3,4,6,7,8,9,10};
//		int n=arr.length+1;
//		int sum=(n*(n+1))/2;
//		int actualSum=0;
//		for(int i=0;i<arr.length;i++) {
//			actualSum=actualSum+arr[i];
//		}
//		int missingNum=sum-actualSum;
//		System.out.println("Missing number is : "+missingNum);
		
		String s="This is Dhiraj Mehta This is Dhiraj Mehta";
		String lowerCase="";
		String upperCase="";
		int mid=s.length()/2;
		for(int i=0;i<s.length();i++) {
			if(i<=mid) {
				lowerCase=lowerCase+Character.toLowerCase(s.charAt(i));
			}else {
				upperCase=upperCase+Character.toUpperCase(s.charAt(i));
			}
		}System.out.println(lowerCase +" "+upperCase);
	}
}
