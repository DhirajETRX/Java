package com.example;

import java.util.ArrayList;
import java.util.List;

public class Demo4 {
	public static void main(String[] args) {
		int arr[]= {1,2,5,7,9,4,6,3,8};
		int ecount=0, ocount=0;
		int total1 =0, total2 =0;
		List<Integer> l1=new ArrayList<>();
		List<Integer> l2=new ArrayList<>();
		for(int i=0;i<arr.length;i++) {
			if(arr[i]%2==0) {
				l1.add(arr[i]);
				ecount=ecount+1;
			}else {
				l2.add(arr[i]);
				ocount=ocount+1;
			}
		}
		for(int no:l1) {
			total1=total1+no;
		}
		System.out.println("Total even numbers are : "+ecount);
		System.out.println("Total even no. "+l1.size());
		System.out.print("Even numbers are : "+l1);
		System.out.println("\nSum of even numbers are : "+total1);
		System.out.println("------------------------------------>");
		for(int no:l2) {
			total2=total2+no;
		}
		System.out.println("Total odd numbers are : "+ocount);
		System.out.print("Odd numbers are : "+l2);
		System.out.println("\nSum of odd numbers are : "+total2);
	}
}
