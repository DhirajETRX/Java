package com.example;

import javax.xml.stream.events.Characters;

//WAJP to find out total number of characters in a string, Space(' '),Comma(,) should not be 
//counted as a character 
// Input = ab, cd, xyz
// Output = 7
public class Demo6 {
	public static void main(String[] args) {
//		String s="ab, cd, xyz";
//		int n=s.length();
//		String str="";
//		for(int i=0;i<n;i++) {
//			if(Character.isAlphabetic(s.charAt(i))) {
//				str=str+s.charAt(i);
//			}
//		}System.out.println(str.length());
		
		
		String s="ab, cd, xyz";
		int n=s.length();
		int count=0;
		for(int i=0;i<n;i++) {
			if(s.charAt(i)!=' ' && s.charAt(i)!=',') {
				count++;
			}
		}System.out.println(count);
	}
}
