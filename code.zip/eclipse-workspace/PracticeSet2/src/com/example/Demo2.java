package com.example;

public class Demo2 {
	public static void main(String[] args) {
		String s="DhirajMehta";
		removeChar(s, 'h');
	}
	public static void removeChar(String s,char h) {
		int n=s.length();
		String str="";
		for(int i=0;i<n;i++) {
			if(s.charAt(i) !=h) {
				str=str+s.charAt(i);
			}
		}System.out.println(str);
	}
}
