package com.example;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
//WAJP to count strings whose length is greater than 5 in the given list

public class Demo10 {
	public static void main(String[] args) {
		List<String> str=Arrays.asList
				("Welcome","to","cloudtech","for","Java","Interview","coding","questions");
		Long count= str.stream().filter(s -> s.length()>5).count();
		System.out.println("Strings whose length is greater than 5 are : "+count);
	}
}

//int n=10;
//Random random=new Random();
//random.ints(1, 100).limit(n).forEach(System.out::println);