package com.example;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Demo5 {
	public static void main(String[] args) {
		List<Integer> list1=Arrays.asList(1,2,3,4,5,6);
		List<Integer> list2=Arrays.asList(4,5,6,7,8,9);
		
		// Concatenating two list by using Java 8 features
		Stream<Integer> fullList=Stream.concat(list1.stream(), list2.stream());
		List<Integer> allElements=fullList.collect(Collectors.toList());
		System.out.print(allElements+" ");
		System.out.println();
		
		// Find or remove duplicate numbers by using Java 8
		Set<Integer> hs=new HashSet<>();
		allElements.stream().filter(p -> !hs.add(p)).forEach(System.out::println);
		System.out.println("------------------------------------------------");	
		
		// Another way of find or remove duplicate number by using Java 8
		Set<Integer> uniqueNumber= allElements.stream().collect(Collectors.toSet());
		System.out.println("Unique numbers are : ");
		System.out.println(uniqueNumber);
		System.out.println("------------------------------------------------");	
		
		// Find max and min number by using Java 8
		Integer max= uniqueNumber.stream().max((a,b) ->a-b).get();
		System.out.println(max);
		
		Integer max1= uniqueNumber.stream().max((x,y)->x.compareTo(y)).get();
		System.out.println(max1);
	}
}
