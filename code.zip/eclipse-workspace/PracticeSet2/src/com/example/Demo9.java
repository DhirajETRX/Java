package com. example;

import java. util.Arrays;

//WAJP to separate positive and negative numbers from an array and print the count of 
//total positive and negative number
//input
//arr[]=2,5,4,-6,-3,-8,9,7,-9,3
//output
//total positive number are =7
//{2,5,4,9,7,3}
//total negative number are =4
//{-6,-3,-8,-9}
public class Demo9 {
	public static void main(String[] args) {
		int arr[]= {2,5,4,-6,-3,-8,9,7,-9,3};
		int parr[]=new int[10];
		int narr[]=new int[10];
		int pcount=0, ncount=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]<0) {
				narr[ncount]=arr[i];
				ncount++;
			}else {
				parr[pcount]=arr[i];
				pcount++;
			}
		}
		System.out.println("negative element : "+ncount);
		System.out.println("positive element : "+pcount);
		System.out.println("Negative arrays are : ");
		separate(narr, ncount);
		System.out.println("Positive arrays are : ");
		separate(parr, pcount);
	}
	
	public static void separate(int arr[],int size) {
		for(int i=0;i<size;i++) {
			System.out.println(arr[i]+" ");
		}
	}
}
