package com.example;

import java.util.HashSet;

public class Demo8 {
	public static void main(String[] args) {
		
		//Max & Min
//		int a[]=new int[] {9,4,6,8,21,7,3,5};
//		int max=a[0];
//		for(int i=1;i<a.length;i++) {
//			if(max<=a[i]) {
//				max=a[i];
//			}
//		}
//		System.out.println("Max is "+max);
		
		
		//Remove Duplicate Pattern 1
//		int a[]={1,2,2,3,4,5,5};
//		int temp[]=new int[a.length];
//		int j=0;
//		for(int i=0;i<a.length-1;i++) {
//			if(a[i]!=a[i+1]) {
//				temp[j]=a[i];
//				j++;
//			}
//		}
//		temp[j]=a[a.length-1];
//		for(int i=0;i<temp.length;i++) {
//			System.out.print(temp[i]+" ");
//		}
		
		
		//Remove Duplicate Pattern 2
//		int a[]={1,2,2,3,4,5,5};
//		int j=0;
//		for(int i=0;i<a.length-1;i++) {
//			if(a[i]!=a[i+1]) {
//				a[j]=a[i];
//				j++;
//			}
//		}
//		a[j]=a[a.length-1];
//		for(int i=0;i<j+1;i++) {
//			System.out.print(a[i]+" ");
//		}
		
		
		//Remove Duplicate Pattern 3
//		int a[]= {1,2,3,2,4,5,6,5};
//		HashSet<Integer> hs=new HashSet<>();
//		for(int i=0;i<a.length;i++) {
//			hs.add(a[i]);
//		}
//		for(int n:hs) {
//			System.out.print(n+" ");
//		}
//		System.out.println(hs);
		
		
		
		
		
		//Remove Duplicate and find Kth postion number
		int a[]={4390,434,4538943,4385,433,3322,32242,554,1};
		HashSet<Integer> set=new HashSet<>();
		for(int b:a) {
			set.add(b);
		}System.out.println(set);
		int k=3;
		for(int i=0;i<a.length-1;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]<a[j]) {
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
			if(i==k-1) {
				System.out.println("Element at 3rd postion "+a[i]);
			}
		}
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	}
}
