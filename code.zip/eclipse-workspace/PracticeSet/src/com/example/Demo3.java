package com.example;

public class Demo3 {
	public static void main(String[] args) {
		
		//Pattern 1
		for(int i=1;i<=5;i++) {
			for(int j=1;j<=i;j++) {
				if(i>=2 && j<=i-1) {
					System.out.print(" ");
				}else {
					System.out.print("*");
				}
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		//Pattern 2
		for(int i=1;i<=5;i++) {
			for(int j=5;j>=i;j--) {
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++) {
				if(i>=2 && k>1) {
					System.out.print(" ");
				}else {
					System.out.print("*");
				}
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		//Combined Pattern 1 & 2
		for(int i=1;i<=5;i++) {
			for(int j=1;j<=i;j++) {
				if(i>=2 && j<=i-1) {
					System.out.print(" ");
				}else {
					System.out.print("*");
				}
			}
			System.out.println();
		}
		
		for(int i=1;i<=6;i++) {
			for(int j=5;j>=i;j--) {
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++) {
				if(i>=2 && k>1) {
					System.out.print(" ");
				}else {
					System.out.print("*");
				}
			}
			System.out.println();
		}
		
		
	}
}
