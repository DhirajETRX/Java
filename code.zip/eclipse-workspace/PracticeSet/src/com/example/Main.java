package com.example;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
	public static void main(String[] args) {
		Patient p1=new Patient("A",20,"Corona",9876565d);
		Patient p2=new Patient("B",26,"Corona",9867653d);
		Patient p3=new Patient("C",30,"Fever",8765d);
		Patient p4=new Patient("D",25,"Corona",34567d);
		Patient p5=new Patient("E",43,"Corona",76585d);
		
		List<Patient> list=Arrays.asList(p1,p2,p3,p4,p5);
//		list.stream().filter(p-> p.getDisease().equals("Corona")&& p.getAge()<=25).forEach(System.out::println);
		Double averageBill= list.stream().filter(p-> p.getDisease().equals("Corona")).
		collect(Collectors.averagingDouble(Patient::getBill));
		System.out.println("Average Bill Amount : "+averageBill);
	}
}
