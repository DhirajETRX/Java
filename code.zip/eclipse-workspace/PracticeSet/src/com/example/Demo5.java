package com.example;

import java.util.Scanner;

public class Demo5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter lenght of an array");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter an Array element");
		for(int i=0;i<arr.length;i++) {
			System.out.println("Enter an array");
			arr[i]=sc.nextInt();
		}
		System.out.println("Array element before sorting");
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		
		//Sorting part
		for(int i=0;i<=arr.length-2;i++) {
			for(int j=0;j<=arr.length-2-i;j++) {
				if(arr[j]>arr[j+1]) {
					int help=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=help;
				}
			}
		}
		System.out.println("Array after sorting");
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		
		//Searching part
		System.out.println("Enter key value to search");
		int key=sc.nextInt();
		int low=0;
		int high=arr.length-1;
		int mid;
		while(low<=high) {
			mid=(low+high)/2;
			if(key==arr[mid]) {
				System.out.println("Element found at index "+mid);
				System.exit(0);
			}else if(key>arr[mid]) {
				low=mid+1;
				high=high;
			}else {
				low=0;high=mid-1;
			}
		}
		System.out.println("Element not found");
	}
}
