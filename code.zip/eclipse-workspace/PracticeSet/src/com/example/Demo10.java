package com.example;

import java.util.Scanner;

public class Demo10 {
	public static void main(String [] args){
		Scanner sc=new Scanner(System.in);
	
		final int COKE_Price=35;
		final int PEPSI_Price=45;
		final int SODA_Price=55;

		System.out.println("Welcome to vending machine");
		System.out.println("1.Coke-Rupee"+ COKE_Price);
		System.out.println("2.Pepsi-Rupee"+ PEPSI_Price);
		System.out.println("3.Soda-Rupee"+ SODA_Price);

		System.out.println("Enter your choice(1-3):");
		int choice=sc.nextInt();
		System.out.println("Insert coins(1,5,10,25):-");
		int coins=sc.nextInt();
		int price =0;
		String product=" ";
		
		switch(choice){
			case 1:
				price=COKE_Price;
				product="Coke";break;
			case 2:
				price=PEPSI_Price;
				product="Pepsi";break;
			case 3:
				price=SODA_Price;
				product="Soda";break;

			default :
				System.out.println("Invalid choice");
				return;
				
		}

		if(coins<price){
			System.out.println("coin not found please insert more coins");
		}else{
			int change=coins-price;
			System.out.println(product);
			System.out.println(change);
		}
		System.out.println("Do you want refund?(yes/no):");
		String refundChoice=sc.next();
		if(refundChoice.equalsIgnoreCase("yes")){
			System.out.println("Refunding coins: Rs."+coins);
		}
		System.out.println("Thank you for using the Vending Machine");
	}
}
