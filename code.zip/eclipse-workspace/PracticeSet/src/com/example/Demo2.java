package com.example;

public class Demo2 {
	
	
	public static void main(String[] args) {
		
		
		//Pattern 1
		for(int i=1;i<=4;i++) {
			for(int j=4;j>=i;j--) {
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++) {
				System.out.print(" *");
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		//Another way of Pattern 1
		for(int i=1;i<=4;i++) {
			for(int j=5;j>=1;j--) {
				if(j>i) {
					System.out.print(" ");
				}else {
					System.out.print(" *");
				}
			}
			System.out.println();
		}
		
		System.out.println("------------------------------------------------------->");
		
		//Pattern 2
		for(int i=1;i<=4;i++) {
			for(int j=4;j>=i;j--) {
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++) {
				System.out.print("*");
			}
			for(int l=2;l<=i;l++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		//Another way of Pattern 2
		for(int i=1;i<=4;i++) {
			for(int j=4;j>=i;j--) {
				System.out.print(" ");
			}
			for(int k=1;k<(i*2);k++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		System.out.println("------------------------------------------------------->");
		//Pattern 3
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(" ");
			}
			for(int k=4;k>=i;k--) {
				System.out.print("*");
			}
			for(int l=3;l>=i;l--) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		//Another way of Pattern 3
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(" ");
			}
			for(int k=9;k>(i*2);k--) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
