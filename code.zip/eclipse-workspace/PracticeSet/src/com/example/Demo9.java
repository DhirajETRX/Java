package com.example;

import java.util.Scanner;

public class Demo9 {
	public void insertionSort(int a[]) {
		
		for(int i=0;i<=a.length-1;i++) {
			int item=a[i];
			int j=i-1;
			while(j>=0 && a[j]>item) {
				a[j+1]=a[j];
				j--;
			}
			a[j+1]=item;
		}
	}
	public static void main(String[] args) {
		int a[]= {3,5,9,1,4,7,6};
		Demo9 d=new Demo9();
		d.insertionSort(a);
		for(int sort:a) {
			System.out.print(sort+" ");
		}
	}
}
