package com.example;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class UniqueNo {
public static void main(String[] args) {
		
//		int arr[]= {33,4984,32,948,33,7643,21,2228,32,21};		
//		int temp[]=new int[arr.length];
//		int j=0;
//		Arrays.sort(arr);
//		for(int i=0;i<arr.length-1;i++) {
//			if(arr[i]!=arr[i+1]) {
//				temp[j]=arr[i];
//				j++;
//			}
//		}
//		temp[j]=arr[arr.length-1];
//		for(int i=0;i<temp.length;i++) {
//			System.out.print(temp[i]+" ");
//		}
		
		
		
//		int arr[]= {33,4984,32,948,33,7643,21,2228,32,21};
//		int j=0;
//		Arrays.sort(arr);
//		for(int i=0;i<arr.length-1;i++) {
//			if(arr[i]!=arr[i+1]) {
//				arr[j]=arr[i];
//				j++;
//			}
//		}
//		arr[j]=arr[arr.length-1];
//		for(int i=0;i<j+1;i++) {
//			System.out.print(arr[i]+" ");
//		}
		
		
		int arr[]= {33,4984,32,948,33,7643,21,2228,32,21};
		Set<Integer> hs=new HashSet<>();
		for(int i=0;i<arr.length;i++) {
			hs.add(arr[i]);
		}
		for(int unique:hs) {
			System.out.print(unique+" ");
		}
		
		
		
		System.out.println();
		int k=3;
		for(int i=0;i<arr.length-1;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]<arr[j]) {
					int help=arr[i];
					arr[i]=arr[j];
					arr[j]=help;
				}
			}
			if(i==k-1) {
				System.out.println("3rd largest number : "+arr[i]);
			}
		}
		for(int a:arr) {
			System.out.println("Sorted array : "+a);
		}
	}
}
