package com.example;

public class Demo7 {
	public void iSort(int a[]) {
		int item;
		int j;
		for(int i=1;i<=a.length-1;i++) {
			item=a[i];
			j=i-1;
			while(j>=0 && a[j]>item) {
				a[j+1]=a[j];
				j--;
			}
			a[j+1]=item;
		}
	}
	public static void main(String[] args) {
		int a[]=new int[] {9,4,6,8,2,7,3};
		Demo7 d=new Demo7();
		d.iSort(a);
		System.out.println("After sorting");
		for(int i=0;i<a.length;i++) {
			System.out.print(a[i]+" ");
		}
	}
}
