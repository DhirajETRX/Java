package com.example;

public class Demo4 {
	public static void main(String[] args) {
		
		//Pattern 1
		for(int i=1;i<=4;i++) {
			for(int j=4;j>=i;j--) {
				System.out.print(" ");
			}
			for(int k=1;k<(i*2);k++) {
				if(k>1 && k<(i*2)-1) {
					System.out.print(" ");
				}else {
					System.out.print("*");
				}
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		
		
		//Pattern 2
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=4;j++) {
				if(i>=2&&j>=2 && i<=3&&j<=3) {
					System.out.print(" ");
				}else {
					System.out.print("*");
				}
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		
		//Number Patter 1
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(i);
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		
		//Number Patter 2
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(j);
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		//Number Pattern 3
		int count=0;
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=i;j++) {
				count=count+1;
				System.out.print(count);
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		
		//Number Pattern 4
		for(int i=1;i<=4;i++) {
			for(int j=i;j>=1;j--) {
				System.out.print(j);
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		//Number Pattern 5
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(j);
			}
			for(int k=i-1;k>=1;k--) {
				System.out.print(k);
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		
		//Number Pattern 6
		for(int i=1;i<=5;i++) {
			for(int j=5;j>=i;j--) {
				System.out.print(j);
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		//Number Pattern 7
		for(int i=1;i<=8;i++) {
			int n=i;
			for(int j=1;j<=i;j++) {
				System.out.print(n+" ");
				n=n+8-j;
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		//Number Pattern 8
		int count1=0;
		for(int i=1;i<=5;i++) {
			for(int j=1;j<=3;j++) {
				count1=count1+1;
				System.out.print(count1);
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------------->");
		
		
		
		//Number Pattern 9
		int count12=0;
		for(int i=1;i<=8;i++) {
			if(i%2!=0) {
				for(int j=1;j<=5;j++) {
					count12=count12+1;
					System.out.print(count12+" ");
				}
			}else {
				int temp=count12+1;
				for(int j=count12+5;j>=temp;j--) {
					count12=count12+1;
					System.out.print(j+" ");
				}
			}
			System.out.println();
		}
	}
}
