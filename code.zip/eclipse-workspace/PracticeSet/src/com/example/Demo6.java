package com.example;

import java.util.Scanner;

public class Demo6 {
	public void sSort(int a[]) {
		int min;
		int pos;
		int help;
		for(int i=0;i<=a.length-2;i++) {
			min=a[i];
			pos=i;
			for(int j=i+1;j<=a.length-1;j++) {
				if(a[j]<min) {
					min=a[j];
					pos=j;
				}
			}
			help=a[i];
			a[i]=a[pos];
			a[pos]=help;
		}
	}
	public static void main(String[] args) {
		int a[]=new int[] {9,4,6,8,2,7,3};
		Demo6 d=new Demo6();
		d.sSort(a);
		System.out.println("After sorting");
		for(int i=0;i<a.length;i++) {
			System.out.print(a[i]+" ");
		}
		System.out.println();
		
		int key=7;
		int low=0;
		int high=a.length-1;
		int mid;
		while(low<=high) {
			mid=(low+high)/2;
			if(key==a[mid]) {
				System.out.println("found at index "+mid);
				System.exit(0);
			}else if(key>a[mid]) {
				low=mid+1;
				high=high;
			}else {
				low=0;
				high=mid-1;
			}
		}
		System.out.println("not found");
	}
}
