package com.example;

public class Demo {
	public static void main(String[] args) {
		
		//1st pattern
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("----------------------->");
		
		//2nd Pattern
		for(int j=4;j>=1;j--) {
			for(int i=1;i<=j;i++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("----------------------->");
		//Another way of 2nd pattern
		for(int i=1;i<=4;i++) {
			for(int j=4;j>=i;j--) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		System.out.println("----------------------->");
		//Combined Pattern 
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		for(int j=3;j>=1;j--) {
			for(int i=1;i<=j;i++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
	}
}
