package com.example;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Patient{
	private String Name;
	private int age;
	private String disease;
	private Double bill;
	
	public Patient() {
		
	}

	public Patient(String name, int age, String disease, Double bill) {
		super();
		Name = name;
		this.age = age;
		this.disease = disease;
		this.bill = bill;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getDisease() {
		return disease;
	}

	public void setDisease(String disease) {
		this.disease = disease;
	}

	public Double getBill() {
		return bill;
	}

	public void setBill(Double bill) {
		this.bill = bill;
	}

	@Override
	public String toString() {
		return "Patient [Name=" + Name + ", age=" + age + ", disease=" + disease + ", bill=" + bill + "]";
	}

	
		
}