package com.example;

import java.util.Scanner;

public class BinarySearchDemo2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length of an element");
		int n = sc.nextInt();
		System.out.println("Enter an array element");
		int arr[] = new int[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.println("Enter an element");
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter key value");
		int key = sc.nextInt();
		int low = 0;
		int high = arr.length - 1;

		while (low <= high) {
			int mid = (low + high) / 2;
			if (key == arr[mid]) {
				System.out.println("Element found at index "+mid);
				System.exit(0);
			} else if (key > arr[mid]) {
				low = mid + 1;
				
			} else {
				high = mid - 1;
				
			}
		}
		System.out.println("Not found");
	}
}
