package com.example;

public class BinarySearchDemo {

	public static void main(String[] args) {
		int arr[]=new int[]{10,20,30,40,50,};
		int low=0;
		int high=arr.length-1;
		int key=10;
		
		while(low<=high) {
			int mid=(low+high)/2;
		if(key==arr[mid]) {
			System.out.println("Element found at index "+mid);
			System.exit(0);
		}else if (key>=arr[mid]) {
			low=mid+1;
		}else
			high=mid-1;
	}
		System.out.println("not found");
	}
}
