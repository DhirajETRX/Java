package com.example;

import java.util.Scanner;

public class LinearSearchDemo {

	public static void main(String[] args) {
//		int arr[]=new int[]{10,20,30,40,50};
//		int key=40;
//		for(int i=0;i<arr.length;i++) {
//			if(key==arr[i]) {
//				System.out.println("Element found at index "+i);break;
//		}
//			else
//				System.out.println("Element not found");
//		}

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length of an array");
		int n = sc.nextInt();
		System.out.println("Enter the array element ");

		int arr[] = new int[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.println("Enter an element");
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter the key value");
		int key = sc.nextInt();
		for (int i = 0; i < arr.length; i++) {
			if (key == arr[i]) {
				System.out.println("Element found at index " + i);
				System.exit(0);
			}
				
		}
		System.out.println("Element not found");
	}
}
