package com.sort.example;

import java.util.Scanner;

public class ISort {
	public void insertionSort(int a[]) {
		int item;
		int j;
		for (int i = 1; i <= a.length - 1; i++) {
			item = a[i];
			j = i - 1;

			while (j >= 0 && a[j] > item) {
				a[j + 1] = a[j];
				j--;
			}
			a[j+1]=item;
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length of an array");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter an array element");
		for(int i=0;i<arr.length;i++) {
			System.out.println("Enter an element");
			arr[i]=sc.nextInt();
		}
		System.out.println("Array before sorting");
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		ISort sort=new ISort();
		sort.insertionSort(arr);
		System.out.println("Array after sorting");
		for(int i=0;i<=arr.length-1;i++) {
			System.out.print(arr[i]+" ");
		}
	}
}
