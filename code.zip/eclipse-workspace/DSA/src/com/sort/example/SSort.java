package com.sort.example;

import java.util.Scanner;

public class SSort {

	public void selectionSort(int a[]) {
		int min;
		int pos;
		int help;
		for(int i=0;i<=a.length-2;i++) {
			min=a[i];
			pos=i;
			for(int j=i+1;j<=a.length-1;j++) {
				if(a[j]<min) {
					min=a[j];
					pos=j;
				}
			}
			help=a[i];
			a[i]=a[pos];
			a[pos]=help;
		}
	}
	public static void main(String[] args) {
		SSort ss=new SSort();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length of an array");
		int n=sc.nextInt();
		System.out.println("Enter an array element");
		int arr[]=new int[n];
		for(int i=0;i<arr.length;i++) {
			System.out.println("Enter an element");
			arr[i]=sc.nextInt();
		}
		System.out.println("Array element before sorting");
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}System.out.println();
		ss.selectionSort(arr);
		System.out.println("Array element after sorting");
		for(int i=0;i<=arr.length-1;i++) {
			System.out.print(arr[i]+" ");
		}
	}
}
