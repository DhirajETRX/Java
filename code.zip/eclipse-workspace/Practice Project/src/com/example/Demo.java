package com.example;

public class Demo {

	int empCode;
	String empName;
	String empEmail;

	public Demo(int ec,String en, String ee){
		empCode=ec;
		empName=en;
		empEmail=ee;
		}
	public void display(){
		System.out.println(empCode +" "+ empName +" "+ empEmail);
		}
	public static void main(String[] args){
	Demo d1 = new Demo(1,"Dhiraj","d1@c.c");
	d1.display();
	Demo d2 = new Demo(2,"soni","s11@c.c");
	d2.display();
	Demo d3 = new Demo(3,"suraj","suraj1@c.c");
	d3.display();
	}

}
