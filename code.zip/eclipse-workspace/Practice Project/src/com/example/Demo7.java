package com.example;
//Methods
public class Demo7 {
	public void add(){
		int a=8;
		int b=78;
		int c=a+b;
		System.out.println(c);
	}
	
	public void sub(int x,int y) {
		int z=x-y;
		System.out.println(z);
	}
	
	public int mult() {
		int a=7;
		int b=9;
		int c=a*b;
		return c;
	}
	
	public int div(int x,int y) {
		int z=x/y;
		return z;
	}
	
	public static void main(String[] args) {
		Demo7 d=new Demo7();
		d.add();
		d.sub(7676, 65);
		int res=d.mult();
		System.out.println(res);
		int res1=d.div(6675748, 7856);
		System.out.println(res1);
	}
}
