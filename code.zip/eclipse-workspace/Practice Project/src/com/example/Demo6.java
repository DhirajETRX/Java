package com.example;

import java.util.Scanner;
//WAJP to compare three number given by user and 
public class Demo6 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter 1st number");
//		int a=sc.nextInt();
//		System.out.println("Enter 2nd number");
//		int b=sc.nextInt();
//		System.out.println("Enter 3rd number");
//		int c=sc.nextInt();
//		if(a>b && a>c) {
//			System.out.println("A is greater "+a);
//		}
//		else if(b>a && b>c) {
//			System.out.println("B is greater "+b);
//		}else {
//			System.out.println("C is greater "+c);
//		}
		
		
		
//		Give a point o(x,y), WAJP to find which co-ordinate it belongs to
		System.out.println("Enter value of X ");
		int x=sc.nextInt();
		System.out.println("Enter value of Y ");
		int y=sc.nextInt();
		if(x>0 && y>0) {
			System.out.println("Entered piont is in 1st quadrant");
		}else if(x<0 && y>0) {
			System.out.println("Entered piont is in 2nd quadrant");
		}else if(x<0 && y<0) {
			System.out.println("Entered point is in 3rd quadrant");
		}else if(x>0 && y<0) {
			System.out.println("Entered point is in 4th quadrant");
		}else if(x==0 && y==0) {
			System.out.println("Entered point is at origin");
		}else if(x==0 && y>0) {
			System.out.println("Entered point is on y-axis");
		}else {
			System.out.println("Entered point is on x-axis");
		}
	}
}
