package com.example;

import java.util.Arrays;
import java.util.Scanner;

public class Practice {
	public static void main(String[] args) {
//		for(int i=0;i<=100;i++) {
//			if(i%2!=0) {
//				System.out.println("Odd no. are : "+i);
//			}
//		}
		
		
	//Array inside arrays
		int arr1[]= {23,34,22,54};
		int arr2[]= {1,2,3,44,4};
		int arr3[]= {45,66,64,54,9};
		int arr4[]= {53,52,96,65,87};
		int arrayOfArrays[][]= {arr1,arr2,arr3,arr4};
		System.out.println(Arrays.deepToString(arrayOfArrays));
	}
}
