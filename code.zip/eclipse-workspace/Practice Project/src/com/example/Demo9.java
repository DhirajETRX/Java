package com.example;

import java.util.Scanner;

//WAJP to find the sum of numbers in given range
public class Demo9 {
//	public int nSum(int a,int b) {
//		int x=0;
//		for(int i=a;i<=b;i++) {
//			x=x+i;
//		}return x;
//	}
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter value of a ");
//		int a=sc.nextInt();
//		System.out.println("Enter value of b ");
//		int b=sc.nextInt();
//		Demo9 d=new Demo9();
//		int y=d.nSum(a, b);
//		System.out.println(y);
//	}
	
	
	
	//WAJP to check whether a given number is even or odd
	
//	public int check() {
//		Scanner sc =new Scanner(System.in);
//		System.out.println("Enter any number");
//		int n=sc.nextInt();
//		if(n%2==0) {
//			System.out.println("Given number is even");
//		}else {
//			System.out.println("Given number is odd");
//		}return n;
//	}
//	public static void main(String[] args) {
//		Demo9 d=new Demo9();
//		d.check();
//		System.out.println(d.check());
//	}
	
	
	public int check(int n) {
		if(n%2==0) {
			System.out.println("Given number is even");
			}else {
				System.out.println("Given number is odd");
			}return n;
		}public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter value of n ");
			int n=sc.nextInt();
			
			Demo9 d=new Demo9();
			System.out.println(d.check(n));
		}
}
