package com.example;

import java.util.Scanner;

public class Test {
	//153,1634,
	public static void main(String[] args) {
		int n=153;
		int t1=n;
		int len=0;
		while(t1!=0) {
			int rem=t1%10;
			len=len+1;
			t1=t1/10;
		}
		
		int t2=n;
		int rev=0;
		int arm=0;
		while(t2!=0) {
			int mul=1;
			int rem=t2%10;
			for(int i=0;i<len;i++) {
				mul=mul*rem;
			}
			arm=arm+mul;
			t2=t2/10;
		}
		if(n==arm) {
			System.out.println("no is armstrong ");
		}else {
			System.out.println("no is not armstrong ");
		}
		
	}
	
}
