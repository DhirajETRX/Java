package com.example;

import java.util.Scanner;

//WAJP to swap number
public class Demo1 {
	int fact=1;
	public static void main(String[] args) {
//		int a=10,b=20;
//		int t;
//		t=a;
//		a=b;
//		b=t;
		
		//Another way
//		a=a+b;
//		b=a-b;
//		a=a-b;
//		System.out.println("a "+a);
//		System.out.println("b "+b);
		
		
		//Table of 2
//		int a=2;
//		for(int i=1;i<=10;i=i+1) {
//			System.out.println(i*a);
//		}
		
		
		//Factorial of number
//		int n=5,fact=1;
//		for(int i=1;i<=n;i++) { //for(int i=n;i>=1;i--)
//			fact=fact*i;
//		}System.out.println(fact);
		
		
	
		//Factorial number with method
//		public int fact(int n) {
//			int fact=1;
//			for(int i=1;i<=n;i++) {
//				fact=fact*i;
//			}return fact;
//		}
//		public static void main(String[] args) {
//			Scanner s=new Scanner(System.in);
//			System.out.println("Enter number here");
//			int n=s.nextInt();
//			Demo1 d=new Demo1();
//			int res=d.fact(n);
//			System.out.println(res);
//		}
		
		//Reccrusion Factorial number

		Demo1 d=new Demo1();
		int res=d.getFact(5);
		System.out.println(res);
		
	}
	public int getFact(int n) {
		
		if(n>1) {
			fact=fact*n;
			getFact(n-1);
		}return fact;
	}
}
