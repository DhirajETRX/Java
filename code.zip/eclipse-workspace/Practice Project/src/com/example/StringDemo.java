package com.example;

import java.util.Scanner;

public class StringDemo {

	public static void main(String[] args) {
//		String s="hello world";
//		System.out.println(s.charAt(4));
//		System.out.println(s.toUpperCase());
//		System.out.println(s.length());
		
		
//		int a[]= {1,4,7,3,2,5,8,6};
//		int n=a.length+1;
//		int sum=(n*(n+1))/2;
//		int actualSum=0;
//		for(int i=0;i<a.length;i++) {
//			actualSum=actualSum+a[i];
//		}
//		System.out.println(actualSum);
//		System.out.println("missing no is "+(sum-actualSum));
		
		
		int input[]= {1,4,7,9,33,89,100,11,64,25};
		int copy[]=new int[101];
		for(int itr:input) {
			copy[itr]=1;
		}
		for(int i=1;i<copy.length;i++) {
			if(copy[i]==0) {
				System.out.print(i+" ");
			}
		}
	}
}
