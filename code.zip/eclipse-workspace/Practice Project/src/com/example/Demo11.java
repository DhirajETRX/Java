package com.example;

import java.util.Scanner;

//WAJP to find the given number is prime or not
public class Demo11 {
//	public boolean checkPrime(int n) {
//		if(n==0 || n==1) {
//			return false;
//		}else if(n==2) {
//			return true;
//		}else {
//			for(int i=2;i<n;i++) {
//				if(n%i==0) {
//					return false;
//				}
//			}
//			return true;
//		}
//	}
//	
//	public static void main(String[] args) {
//		Demo11 d=new Demo11();
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter any number : ");
//		int a=sc.nextInt();
//		boolean res=d.checkPrime(a);
//		if(res==true) {
//			System.out.println("Entered number is a prime number : ");
//		}else {
//			System.out.println("Entered number is not prime number : ");
//		}
//	}
	
	
	public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter number");
	int n=s.nextInt();
	int temp=0;
	for(int i=2;i<n;i++) {
		if(n%i==0) {
			temp=temp+1;
		}
	}
	if(temp>0) {
		System.out.println("Not prime no");
	}
	else if(n==0 || n==1) {
		System.out.println("not prime number");
		
	}
	else {
		System.out.println("prime no");
	}
	
	
	
	
//	Scanner sc=new Scanner(System.in);
//	int n=sc.nextInt();
//	int temp=0;
//	if(n==0 || n==1) {
//		System.out.println(n+" is not a prime no.");
//		System.exit(0);
//	}
//	for(int i=2;i<n;i++) {
//		if(n%i==0) {
//			temp++;
//		}
//	}
//	if(temp==0) {
//		System.out.println("Given number is prime "+n);
//	}else {
//		System.out.println("Given number is not prime ");
//	}
	
}
}
