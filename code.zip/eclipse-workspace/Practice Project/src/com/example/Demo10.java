package com.example;

import java.util.Scanner;

//WAJP to print all the odd numbers in the given range
public class Demo10 {
	public int check(int n) {
		if(n%2==0) {
			System.out.println("Even no");
		}else {
			System.out.println("Odd no");
		}
		return n;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two number for comparision : ");
		System.out.println("Enter first number : ");
		int a=sc.nextInt();
		System.out.println("Enter second number : ");
		int b=sc.nextInt();
		Demo10 d=new Demo10();
		for(int i=a;i<=b;i++) {
			if(i%2!=0) {
				int res=d.check(i);
				System.out.println(res);
			}
		}
	}
}
