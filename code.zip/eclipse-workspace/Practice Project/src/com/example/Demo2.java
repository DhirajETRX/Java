package com.example;

import java.util.Scanner;

public class Demo2 {
		//Nested for loop
	public static void main(String[] args) {
		for(int i=0;i<=3;i++) {
			System.out.print(i);
			for(int j=0;j<=3;j++) {
				System.out.println(j);
			}
		}
	}
	
	
	
	//WAJP to reverse a number
//	public int reverseno(int n) {
//		int rem=0,rev=0;
//		while(n!=0) {
//			rem=n%10;
//			rev=rev*10+rem;
//			n=n/10;
//		}return rev;
//	}
//	
//	public static void main(String[] args) {
//		Scanner s=new Scanner(System.in);
//		System.out.println("Enter a number : ");
//		int n=s.nextInt();
//		Demo2 d=new Demo2();
//		int res=d.reverseno(n);
//		System.out.println(res);
//	}
	
	
	
		//WAJP to reverse a String without method
//	public static void main(String[] args) {
//		Scanner s=new Scanner(System.in);
//		System.out.println("Enter String value here : ");
//		String str=s.next();
//		String rev="";
//		for(int i=str.length()-1;i>=0;i--) {
//			rev=rev+str.charAt(i);
//		}System.out.println(rev);
//	}
	
	
	
		//WAJP to reverse String using method
//	public String reversestr(String str) {
//		String rev="";
//		for(int i=str.length()-1;i>=0;i--) {
//			rev=rev+str.charAt(i);
//		}return rev;
//	}
//	
//	public static void main(String[] args) {
//		Scanner s=new Scanner(System.in);
//		System.out.println("Enter String : ");
//		String str=s.nextLine();
//		Demo2 d=new Demo2();
//		String res=d.reversestr(str);
//		System.out.println(res);
//	}
	
	
	
		//WAJP to print fibonacci series without method
//	public static void main(String[] args) {
//		int a=0,b=1;
//		int c;
//		for(int i=0;i<=10;i++) {
//			c=a+b;
//			System.out.println(c);
//			a=b;
//			b=c;
//		}
//	}
	
	
		//Fibonacci series with method
//	public int fibo(int c,int a,int b) {
//		for(int i=0;i<=10;i++) {
//			c=a+b;
//			System.out.println(c);
//			a=b;
//			b=c;
//		}return c;
//	}
//	
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter 1st number : ");
//		int a=sc.nextInt();
//		System.out.println("Enter 2nd number : ");
//		int b=sc.nextInt();
//		Demo2 d=new Demo2();
//		int res=d.fibo(b, a, b);
//		System.out.println(res);
//	}
	
	
	
	
	//WAJP to print the palindrome number
//	public static void main(String[] args) {
//		int n=121;
//		int temp=n;
//		int rev=0,rem;
//		while(temp!=0) {
//			rem=temp%10;
//			rev=rev*10+rem;
//			temp=temp/10;
//		}if(n==rev) {
//			System.out.println(n+" is a palindrome number");
//		}else
//			System.out.println(n+" is not a palindrome number");
//	}
	
	
	
	
//	static int rev=0,rem;
//	public int palind(int n) {
//		int temp=n;
//		
//		while(temp!=0) {
//			rem=temp%10;
//			rev=rev*10+rem;
//			temp=temp/10;
//		}
//		return rev;
//	}
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter number");
//		int n=sc.nextInt();
//		Demo2 d=new Demo2();
//		int res=d.palind(n);
//		if(n==rev) {
//			System.out.println(n+" is palindrome number");
//		}else {
//			System.out.println(n+" is not a palindrome number");
//		}
//	}
	
}
