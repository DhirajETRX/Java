package com.example;

import java.util.Scanner;

public class Factorial {

	public int fact(int n) {
		if(n==0)
			return 1;
		else
			return n*fact(n-1);
	}
	public static void main(String[] args) {
		Factorial f= new Factorial();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your factorial number");
		int n=sc.nextInt();
		int res=f.fact(n);
		System.out.println(res);
	}
}
