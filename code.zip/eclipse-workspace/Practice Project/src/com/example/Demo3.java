package com.example;

import java.util.Scanner;

public class Demo3 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter 1st integer number");
		int x=sc.nextInt();
		System.out.println("Enter 2nd integer number");
		int y=sc.nextInt();
		System.out.println("1. Addition 2. Substraction 3. Multiplication 4. Division 5. Modulus");
		int key=sc.nextInt();
		
		if(x==5 && y==5) {
			key=3;
			System.out.println("your answer is 11");
		}
		switch (key) {
		case 1:
			System.out.println((x+y));
			break;
		case 2:
			System.out.println((x-y));
			break;
		case 3:
			System.out.println((x*y));
			break;
		case 4:
			System.out.println((x/y));
			break;
		case 5:
			System.out.println((x%y));
			break;

		default:System.out.println("You entered wrong input");
			break;
		}
	}
}
