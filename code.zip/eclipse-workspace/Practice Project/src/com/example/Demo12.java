package com.example;

import java.util.Scanner;

public class Demo12 {
	public boolean checkPrime(int n) {
		if(n==0||n==1) {
			return false;
		}else if(n==2) {
			return true;
		}else {
			for(int i=2;i<n;i++) {
				if(n%i==0) {
					return false;
				}
			}return true;
		}
	}
	
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two number to get range prime number ");
		System.out.println("Enter first number here : ");
		int a=sc.nextInt();
		System.out.println("Enter second number here : ");
		int b=sc.nextInt();
		Demo12 d=new Demo12();
		for(int i=a;i<=b;i++) {
			System.out.println(d.checkPrime(i));
		}
	}
	



//public static void main(String[] args) {
//	
//	for(int n=1;n<=100;n++) {
//		int temp=0;
//		for(int i=2;i<n;i++) {
//			if(n%i==0) {
//				temp=temp+1;
//			}
//		}
//		if(temp==0) {
//			System.out.println(n);
//		}
//	}
//}
	
}
