package com.example;

import java.util.Scanner;

public class Demo4 {
	public static void main(String[] args) {
		for(int i=0;i<=4;i++) {
			System.out.println(i);
			for(int j=0;j<=3;j++) {
				System.out.println("Dhiraj");
			}
			break;
		}
		
		
		
		
		//WAJP to print Armstrong number
		
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter number");
//		int n=sc.nextInt();
//		int t1=n;int len=0;
//		while(t1!=0) {
//			t1=t1/10;
//			len=len+1;
//		}
//		
//		int t2=n;int arm=0;int rem;
//		while(t2!=0) {
//			rem=t2%10;
//			int mul=1;
//			for(int i=1;i<=len;i++) {
//				
//				mul=rem*mul;
//			}
//			arm=arm+mul;
//			t2=t2/10;
//		}if(n==arm) {
//			System.out.println(n+" is armstrong number");
//		}else {
//			System.out.println(n+" is not a armstrong number");
//		}
	}
}
