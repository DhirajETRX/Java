package com.example;

import java.util.Scanner;

//WAJP to find the greatest two number
public class Demo5 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter any number");
		int x=sc.nextInt();
		System.out.println("Enter number");
		int y=sc.nextInt();
//		if(x>y) {
//			System.out.println("Entered number of x "+x+" is greater than y "+y);
//		}else {
//			System.out.println("Entered number of y "+y+" is greater than x "+x);
//		}
		
		
//		WAJP to find given number is even or odd
		if(x%2==0) {
			System.out.println("Given number of x is  even");
		}else {
			System.out.println("Odd number");
		}
		if(y%2==0) {
			System.out.println("Even number");
		}else {
			System.out.println("Odd number");
		}
		
		
	}
}
