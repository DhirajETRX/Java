package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
//WAJP to count strings whose length is greater than 5 in the given list
public class Demo14 {
	
	public static void main(String[] args) {
		String s = "hello geeks for geeks is computer science portal";
		int k=4;
		
		String[] x=s.split(" ");
		System.out.println(x);
		List<String> l=new ArrayList<>();
		for(String str:x) {
			if(str.length()>k) {
				l.add(str);
			}
		}
		System.out.println(l);
	}
}

