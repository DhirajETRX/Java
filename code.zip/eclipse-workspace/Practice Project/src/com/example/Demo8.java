package com.example;

import java.util.Scanner;

//WAJP to find sum of first 5 naturals number
public class Demo8 {
	
	//With Method
	
//	public int add() {
//		int sum=0;
//		for(int i=1;i<=5;i++) {
//			sum=sum+i;
//		}
//		return sum;
//	}
//	public static void main(String[] args) {
//		Demo8 d=new Demo8();
//		int sum1=d.add();
//		System.out.println(sum1);
//	}
	
	
	//Without Method
//	public static void main(String[] args) {
//		int sum=0;
//		for(int i=1;i<=5;i++) {
//			sum=sum+i;
//		}System.out.println(sum);
//	}
	
	
	
	//WAJP to find the sum of first 'n' natural number where 'n' is the input given by user
//	public int nNaturalNo() {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter value of n number");
//		int n=sc.nextInt();
//		int sum=0;
//		for(int i=1;i<=n;i++) {
//			sum=sum+i;
//		}
//		return sum;
//	}
//	
//	public static void main(String[] args) {
//		Demo8 d=new Demo8();
//		System.out.println(d.nNaturalNo());
//	}
	
	
	public long nNaturalNo(long n) {
		long sum=0;
		for(int i=1;i<=n;i++) {
			sum=sum+i;
		}return sum;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter value of n ");
		long n=sc.nextLong();
		Demo8 d=new Demo8();
		long sum1=d.nNaturalNo(n);
		System.out.println(sum1);
	}
}
