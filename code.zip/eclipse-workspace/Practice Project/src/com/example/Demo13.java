package com.example;

import java.util.Scanner;
//WAJP to get total integer number of given input
public class Demo13 {
//	public static void main(String[] args) {
//		Scanner s=new Scanner(System.in);
//		System.out.println("Enter number here : ");
//		int n=s.nextInt();
//		String str=Integer.toString(n);
//		System.out.println(str.length());
//	}
	
	
//	public static void main(String[] args) {
//		Scanner s=new Scanner(System.in);
//		System.out.println("Enter number here : ");
//		int n=s.nextInt();
//		int count=0;
//		while(n>0) {
//			count++;
//			n=n/10;
//		}System.out.println(count);
//	}
	
	
	
	
	//WAJP to find leap year
	
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter number here : ");
		int years=s.nextInt();
//		if(years%400==0){
//			System.out.println(years+" is a leap year");
//		}else if(years%4==0 && years%100!=0) {
//			System.out.println(years+" is a leap year");
//		}
//		else {
//			System.out.println(years+" is not a leap year");
//		}
		
		if(years%400==0||(years%4==0 && years%100!=0)) {
			System.out.println(years+" is a leap year");
		}else {
			System.out.println(years+" is a not leap year");
		}
	}
	
	
	
}
