package com.example;

public class SecondLargest {
	public static void main(String[] args) {
		int a[]= {6,3,8,4,9,5};
		int temp=0;
		for(int i=0;i<a.length-1;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]<a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}System.out.println("Second Largest is : "+a[1]);
		for(int n:a) {
			System.out.println("Descending order sorted : "+n);
		}
		
	}

//	public static void main(String[] args) {
//		int a[] = { 1, 6, 3, 8, 4, 9, 5, };
//		int largest = Integer.MIN_VALUE;
//		int secondLargest = Integer.MIN_VALUE;
//		for (int i = 0; i < a.length; i++) {
//			if (a[i] > largest) {
//				secondLargest = largest;
//				largest = a[i];
//			} else if (a[i] > secondLargest && a[i] != largest) {
//				secondLargest = a[i];
//			}
//		}
//		System.out.println("Second Largest is: " + secondLargest);
//	}
}
