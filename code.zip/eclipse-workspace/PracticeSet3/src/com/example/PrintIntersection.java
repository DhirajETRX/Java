package com.example;

import java.util.HashSet;
import java.util.Set;

public class PrintIntersection {
	public static void main(String[] args) {
		int arr1[]= {2,3,4,6,7};
		int arr2[]= {7,4,9,6,1};
		printInter(arr1, arr2);
		printUnion(arr1, arr2);
	}
	public static void printInter(int arr1[],int arr2[]) {
		Set<Integer> s=new HashSet<>();
		for(int i=0;i<arr1.length;i++) {
			s.add(arr1[i]);
		}System.out.println("Intersection value or duplicate value : ");
		for(int i=0;i<arr2.length;i++) {
			if(s.contains(arr2[i])) {
				
				System.out.println(arr2[i]);
			}
		}
	}
	public static void printUnion(int arr1[],int arr2[]) {
		Set<Integer> s1=new HashSet<>();
		for(int i=0;i<arr1.length;i++) {
			s1.add(arr1[i]);
		}
		for(int i=0;i<arr2.length;i++) {
			s1.add(arr2[i]);
		}System.out.println("Union or Unique value : ");
		System.out.println(s1);
	}
}
