package com.example;
// FInd the palindrome words from sentence and print them.
public class PalindromeWords {
	public static void main(String[] args) {
		String s="my name is nitin and I can speak malayalam";
		String[] word=s.split(" ");
		for(String words:word) {
			if(isPalindrome(words)) {
				System.out.println(words);
			}
		}
	}
	public static boolean isPalindrome(String s) {
		int i=0;
		int i2=s.length()-1;
		while(i2>=i) {
			if(s.charAt(i)!=s.charAt(i2)) {
				return false;
			}
			i++;
			i2--;
		}
		return true;
	}
}
