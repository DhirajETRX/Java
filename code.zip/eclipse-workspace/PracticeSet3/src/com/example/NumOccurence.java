package com.example;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class NumOccurence {
	
//	public static void elementOccur(int arr[]) {
//		Map<Integer, Integer> map=new HashMap<>();
//		for(int i:arr) {
//			if(map.containsKey(i)) {
//				map.put(i, map.get(i)+1);
//			}else {
//				map.put(i, 1);
//			}
//		}
//		System.out.println("Input Array : "+Arrays.toString(arr));
//		System.out.println("Element count : "+map);
//	}
//	public static void main(String[] args) {
//		int arr[]= {1,2,3,6,2,5,2,1,4,3,2};
//		elementOccur(arr);
//		
//	}
	
	
	
//	public static void main(String[] args) {
//		int arr[]= {1,2,3,6,2,5,2,1,4,3,2};
//		Map<Integer, Integer>map=new HashMap<>();
//		for(int i:arr) {
//			if(map.containsKey(i)) {
//				map.put(i, map.get(i)+1);
//			}else {
//				map.put(i, 1);
//			}
//		}System.out.println(map);
//	}
	
	
	
//	public static void charCount(String s) {
//		Map<Character, Integer> map=new HashMap<>();
//		char[] str=s.toCharArray();
//		for(char c:str) {
//			if(map.containsKey(c)) {
//				map.put(c, map.get(c)+1);
//			}else {
//				map.put(c, 1);
//			}
//		}System.out.println(s+":"+map);
//		
//	}
//	public static void main(String[] args) {
//		String s="All is well";
//		charCount(s);
//	}
	
	
	
//	public static void main(String[] args) {
//		String s="All is well";
//		Map<Character, Integer> map=new HashMap<>();
//		char[] str=s.toCharArray();
//		for(char c:str) {
//			if(map.containsKey(c)) {
//				map.put(c, map.get(c)+1);
//			}else {
//				map.put(c, 1);
//			}
//			s.replaceAll("\\s", "");
//		}System.out.println(s+":"+map);
//	}
	
	
	
	
	public static void duplicateChar(String s) {
		Map<Character, Integer> map=new HashMap<>();
		String s1=s.replaceAll("\\s", "");
		char[] str=s1.toCharArray();
		for(char c:str) {
			if(map.containsKey(c)) {
				map.put(c, map.get(c)+1);
			}else{
				map.put(c, 1);
			}
		}
		System.out.println(map);
		System.out.println("------------------------------------>");
		Set<Character> set=map.keySet();
		System.out.println("Duplicate strings are : "+s);
		for(char ch:set) {
			if(map.get(ch)>1) {
				System.out.println(ch+" : "+map.get(ch));
			}
		}
		//Repeated or nonRepeated
		for(char ch:str) {
			if(map.get(ch)==1) {
				System.out.println("First non repeated charecter is : "+ch);
				break;
			}
		}
		for(char ch:str) {
			if(map.get(ch)>1) {
				System.out.println("First repeated charecter is : "+ch);
				break;
			}
		}
	}
	public static void main(String[] args) {
		String s="Hello I am Dhiraj Kumar";
		duplicateChar(s);
	}
}
