package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Employee2Main {
	public static void main(String[] args) {
		List<Employee2> list=new ArrayList<>();
		list.add(new Employee2("Abc",34,"Male","HR"));
		list.add(new Employee2("Def",43,"Female","IT"));
		list.add(new Employee2("Ghi",76,"Male","SR"));
		list.add(new Employee2("Jkl",56,"Female","IT"));
		list.add(new Employee2("Mno",45,"Male","HR"));
		
		list.stream().map(Employee2::getDepartment).distinct().forEach(System.out::println);
		System.out.println("----------------------------------------------------------->");
		Map<String, Long> depCount= list.stream().collect(
				Collectors.groupingBy(Employee2::getDepartment,Collectors.counting()));
		System.out.println(depCount);
		System.out.println("----------------------------------------------------------->");
		Map<String, Double> avgAge = list.stream().collect(Collectors.groupingBy(
				Employee2::getGender,Collectors.averagingInt(Employee2::getAge)));
		System.out.println(avgAge);
	}
}
