package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeMain {
	public static void main(String[] args) {
		List<Employee> list=new ArrayList<>();
		list.add(new Employee("Amar",26,89657));
		list.add(new Employee("Aman", 23, 27875));
		list.add(new Employee("Anil", 28, 90887));
		System.out.println("Salary before increment\n"+list);
		System.out.println("------------------------------------->");
		List<Employee> list1= list.stream().map(e->{
			if(e.getAge()>25) {
				e.setSalary(e.getSalary()*1.1);
			}
			return e;
		}).collect(Collectors.toList());
		System.out.println("Salary after increment\n"+list);
	}
}
