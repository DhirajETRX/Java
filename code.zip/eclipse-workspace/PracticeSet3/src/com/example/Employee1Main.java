package com.example;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class Employee1Main {
	public static void main(String[] args) {
		List<Employee1> list=Arrays.asList(new Employee1("Aman","CS",89786),new Employee1("Amar","CS",78646),
				new Employee1("Suri","IT",67456),new Employee1("Muri","IT",76656));
		System.out.println("------------------------------------------------------------------------>");
		List<Employee1>list1= list.stream().filter(e-> e.getDepartment()=="CS")
				.collect(Collectors.toList());
		System.out.println(list1);
		System.out.println("------------------------------------------------------------------------>");
		Map<String, List<Employee1>> map= list.stream()
				.collect(Collectors.groupingBy(e-> e.getDepartment()));
		System.out.println(map);
		System.out.println("------------------------------------------------------------------------>");
		Map<String, Employee1> map1 = list.stream().collect(Collectors.groupingBy(e->e.getDepartment(),
				Collectors.collectingAndThen(Collectors.maxBy(
						Comparator.comparingDouble(e->e.getSalary())), Optional::get)));
		System.out.println(map1);
	}
}
