package com.practice.in;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Demo2 {
	
	public static void main(String[] args) {
		List<String> list=Arrays.asList("Aman","Raman","Suman","Aditya","Manoj");
		List<String> collect = list.stream().map(s->s.toLowerCase()).collect(Collectors.toList());
		System.out.println(collect);
		System.out.println("------------------------------------------------->");
		
		
		List<Integer> list1=Arrays.asList(2,3,4,5,6,7,8,9);
		List<Integer> collect2 = list1.stream().filter(x->x%2==0).collect(Collectors.toList());
		System.out.println(collect2);
		System.out.println("------------------------------------------------->");
		
		
		List<Integer> list2=Arrays.asList(2,3,4,5,6,7,8,9);
		Optional<Integer> reduce = list2.stream().filter(x->x%2!=0).reduce((a,b)-> a+b);
		System.out.println(reduce);
		System.out.println("------------------------------------------------->");
		
		
		List<Integer> list3=Arrays.asList(2,3,4,5,6,7,8,9);
		Optional<List<Integer>> map = list3.stream().filter(a->a%2==0).reduce((a,b)->a+b).map(Arrays::asList);
		System.out.println(map);
		System.out.println("------------------------------------------------->");
		
		
		List<Integer> list4=Arrays.asList(2,3,4,5,6,7,8,9);
		List<Integer> collect3 = list4.stream().filter(x->x%2!=0).map(x->x*x).collect(Collectors.toList());
		System.out.println(collect3);
		System.out.println("------------------------------------------------->");
		
		
		List<String> asList=Arrays.asList("Java","Python","C","C++","Ruby","JavaScript","Angular","React");
		List<String> collect4 = asList.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
		System.out.println(collect4);
		
	}
}
