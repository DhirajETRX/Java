package com.practice.in;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.stream.Collectors;

public class Demo7 {

	public static void main(String[] args) {

//		List<Integer> list = Arrays.asList(12, 10, 44, 34, 23, 19, 15);
//		list.stream().map(s->s+" ").filter(s->!s.startsWith("1"))
//		.forEach(System.out::println);

//		List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7,8,9);
//		int sumEven = 0;
//		int sumOdd = 0;
//		for(int i=0;i<numbers.size();i++) {
//			if(numbers.get(i)%2==0) {
//				sumEven = sumEven+numbers.get(i);
//			}else if(numbers.get(i)%2!=0){
//				sumOdd = sumOdd+numbers.get(i);
//			}
//		}System.out.println(sumEven+" "+sumOdd);

		
		
		
//		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
//
//		int sumEven = numbers.stream().filter(n -> n % 2 == 0)
//				.mapToInt(Integer::intValue).sum();
//		int sumOdd = numbers.stream().filter(n -> n % 2 != 0)
//				.mapToInt(Integer::intValue).sum();
//
//		System.out.println(sumEven + "   " + sumOdd);
		
		
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
		Map<Boolean, Integer> map = numbers.stream().collect(Collectors.partitioningBy(
				n->n%2==0, Collectors.summingInt(Integer::intValue)
				));
		int sumEven=map.get(true);
		int sumOdd = map.get(false);
		System.out.println("sum of even : "+sumEven);
		System.out.println("sum of odd : "+sumOdd);

	}
}
