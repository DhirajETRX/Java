package com.practice.in;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class Demo {
	public static void main(String[] args) {
		String str="running";
		char[] ch=str.toCharArray();
		Map<Character, Long> map=new HashMap<>();
		for(char c:ch) {
			if(map.containsKey(c)) {
				map.put(c, map.get(c)+1);
			}else {
				map.put(c, 1l);
			}
		}System.out.println(map);
		Long maxCount=0l;
		char maxChar=' ';
		for(Map.Entry<Character, Long> me : map.entrySet()) {
			if(maxCount<me.getValue()) {
				maxCount=me.getValue();
				maxChar=me.getKey();
				
			}
		}System.out.println(maxChar+" : "+maxCount);
		
		
		
		
		Map<String, Long> map1=Arrays.stream(str.split("")).collect(Collectors.
				groupingBy(s->s,LinkedHashMap::new,Collectors.counting()));
		System.out.println(map1);
	}
}
