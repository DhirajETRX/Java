package com.practice.in;

//Write a Java program to check if a vowel is present in a string.

public class Demo5 {
	public static void main(String[] args) {
		System.out.println(isContainsVowel("hello"));
		System.out.println(isContainsVowel("run"));
		System.out.println(isContainsVowel("dry"));
	}
	public static boolean isContainsVowel(String input) {
		return input.toLowerCase().matches(".*[aeiou].*");
	}
}
