package com.practice.in;

import java.util.Arrays;

//FInd the palindrome words from sentence and print them.

public class Demo4 {
	
	public boolean isPalindrome(String word) {
		int left=0;
		int right=word.length()-1;
		while(left<right) {
			if(word.charAt(left)!=word.charAt(right)) {
				return false;
			}
			left++;
			right--;
		}
		return true;
	}
	
	public static void main(String[] args) {
		
		String s="my name is nitin and he can speak malayalam";
		String[] words=s.split(" ");
		Demo4 d=new Demo4();
		for(String word:words) {
			if(d.isPalindrome(word)) {
				System.out.println(word);
			}
		}
		
		
		
		//Another way
		
//		String s = "my name is nitin and he can speak malayalam";
//        String[] words = s.split("\\s+"); // Splitting the string into words
//        
//        System.out.println("Palindrome words:");
//        for (String word : words) {
//            // Check if the word is a palindrome
//            if (new StringBuilder(word).reverse().toString().equals(word)) {
//                System.out.println(word);
//            }
//        }
		
		
		
		//Another way
		
//		String s = "my name is nitin and he can speak malayalam";
//        String[] words = s.split("\\s+"); // Splitting the string into words
//        
//        System.out.println("Palindrome words:");
//        Arrays.stream(words)
//              .filter(word -> new StringBuilder(word).reverse().toString().equals(word))
//              .forEach(System.out::println);
        
        
        
		// without method
		
//		String s="Hello I am Nitin and my Mom can speak Malyalam";
//		String[] words = s.toLowerCase().split(" ");
		StringBuilder str = new StringBuilder();
		
		for(String word : words) {
			int left=0;
			int right=word.length()-1;
//			System.out.println(right);
			if(word.charAt(left)==word.charAt(right)) {
				str.append(word).append(" ");
			}
			left++;
			right--;
		}
		System.out.println(str.toString());
		
		
		
		
		
	}
}
