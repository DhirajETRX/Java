package com.practice.in;

import java.util.Arrays;

public class Demo1 {
	
	public static void main(String[] args) {
		String s1="top";
		String s2="pot";
		char[] c1=s1.toCharArray();
		char[] c2=s2.toCharArray();
		Arrays.sort(c1);
		Arrays.sort(c2);
		boolean b=Arrays.equals(c1, c2);
		if(b==true) {
			System.out.println("String are anagram");
		}else {
			System.out.println("String are not anagram");
		}
	}
}
