package com.practice.in;


public class Demo10 {
	public static void main(String[] args) {
		int[] arr= {4,6,2,-7,-3,-9,8,-2,-6,5};
		Integer result = findSecPosNumber(arr);
		if(result !=null) {
			System.out.println("last 2nd positive number is : "+result);
		}else {
			System.out.println("ther is no other positive number");
		}
	}
	
	public static Integer findSecPosNumber(int[] arr) {
		Integer lastPosNumber=null;
		Integer lastSecPosNumber=null;
		int count=0;
		for(int i=arr.length-1;i>=0;i--) {
			if(arr[i]>0) {
				count++;
				if(count==2) {
					lastSecPosNumber=arr[i];
				}
			}
			
		}
		return lastSecPosNumber;
	}
}
