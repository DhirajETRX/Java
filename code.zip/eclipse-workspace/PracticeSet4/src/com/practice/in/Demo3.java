package com.practice.in;

public class Demo3 {
	
	public static void main(String[] args) {
		
		//Convert first letter of each word in uppercase
		
		String s="hi I am dhiraj kumar";
		String[] words=s.split(" ");
		StringBuilder sb = new StringBuilder();
		for(String word:words) {
			System.out.println(word);
			sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1)).append(" ");
		}
		String result=sb.toString();
		System.out.println(result);
	}
}
