package com.practice.in;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class Demo6 {

	private int id;
	private String name;
	private String email;
	private String subjects;
	private double marks;
	private int age;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubjects() {
		return subjects;
	}

	public void setSubjects(String subjects) {
		this.subjects = subjects;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Demo6(int id, String name, String email, String subjects, double marks, int age) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.subjects = subjects;
		this.marks = marks;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Demo6 [id=" + id + ", name=" + name + ", email=" + email + ", subjects=" + subjects + ", marks=" + marks
				+ ", age=" + age + "]";
	}

	
	
	public static void main(String[] args) {
		List<Demo6> list = new ArrayList<>();
		list.add(new Demo6(1, "Aman", "aman@gmail.com", "science", 455, 19));
		list.add(new Demo6(2, "Amar", "amar@gmail.com", "science", 355, 21));
		list.add(new Demo6(3, "Raman", "rman@gmail.com", "commerce", 255, 23));
		list.add(new Demo6(4, "Aryan", "aryan@gmail.com", "Arts", 345, 20));
		list.add(new Demo6(5, "Suraj", "suraj@gmail.com", "science", 357, 19));
		list.add(new Demo6(6, "Deepak", "deepak@gmail.com", "Arts", 455, 19));
		
		list.stream().filter(p->p.getName().startsWith("A")&& p.getAge()>19).forEach(System.out::println);
		System.out.println("------------------------------------------------------------------>");
		Demo6 demo6 = list.stream().filter(p->p.getSubjects().equalsIgnoreCase("science"))
				.min(Comparator.comparing(Demo6::getAge)).get();
		System.out.println(demo6);
		System.out.println("------------------------------------------------------------------>");
		list.stream().map(e->{
			if(e.getSubjects().equalsIgnoreCase("science")) {
				e.setMarks(e.getMarks()*1.1);
			}return e;
		}).forEach(System.out::println);
		System.out.println("------------------------------------------------------------------>");
		Map<String, List<Demo6>> collect = list.stream().collect(Collectors.groupingBy(e->e.getSubjects()));
		System.out.println(collect);
		System.out.println("------------------------------------------------------------------>");
		Map<String, Demo6> collect2 = list.stream().collect(Collectors.groupingBy(e->e.getSubjects(),
				Collectors.collectingAndThen(Collectors.maxBy(Comparator.comparing(e->e.getMarks())),
						Optional::get)));
		System.out.println(collect2);
		System.out.println("------------------------------------------------------------------>");
		list.stream().map(e->e.getSubjects()).distinct().forEach(System.out::println);
		System.out.println("------------------------------------------------------------------>");
		list.stream().map(Demo6::getSubjects).distinct().forEach(System.out::println);
		System.out.println("------------------------------------------------------------------>");
		Map<String, Long> collect3 = list.stream().collect(Collectors.groupingBy(Demo6::getSubjects,
				Collectors.counting()));
		System.out.println(collect3);
		System.out.println("------------------------------------------------------------------>");
		Map<String, Double> collect4 = list.stream().collect(Collectors.groupingBy(Demo6::getSubjects,
				Collectors.averagingDouble(Demo6::getMarks)));
		System.out.println(collect4);
	}
}
